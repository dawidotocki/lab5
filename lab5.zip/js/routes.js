angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tabsController.homepageAMG', {
    url: '/page2',
    views: {
      'tab1': {
        templateUrl: 'templates/homepageAMG.html',
        controller: 'homepageAMGCtrl'
      }
    }
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.wydzialy', {
    url: '/page5',
    views: {
      'tab1': {
        templateUrl: 'templates/wydzialy.html',
        controller: 'wydzialyCtrl'
      }
    }
  })

  .state('tabsController.studiuj', {
    url: '/page6',
    views: {
      'tab1': {
        templateUrl: 'templates/studiuj.html',
        controller: 'studiujCtrl'
      }
    }
  })

  .state('quiz', {
    url: '/page7',
    templateUrl: 'templates/quiz.html',
    controller: 'quizCtrl'
  })

  .state('tabsController.elektryczny', {
    url: '/page8',
    views: {
      'tab1': {
        templateUrl: 'templates/elektryczny.html',
        controller: 'elektrycznyCtrl'
      }
    }
  })

  .state('tabsController.nawigacja', {
    url: '/page9',
    views: {
      'tab1': {
        templateUrl: 'templates/nawigacja.html',
        controller: 'nawigacjaCtrl'
      }
    }
  })

  .state('tabsController.przedsiebiorczosc', {
    url: '/page10',
    views: {
      'tab1': {
        templateUrl: 'templates/przedsiebiorczosc.html',
        controller: 'przedsiebiorczoscCtrl'
      }
    }
  })

  .state('tabsController.mechaniczny', {
    url: '/page11',
    views: {
      'tab1': {
        templateUrl: 'templates/mechaniczny.html',
        controller: 'mechanicznyCtrl'
      }
    }
  })

  .state('pytanie1', {
    url: '/page13',
    templateUrl: 'templates/pytanie1.html',
    controller: 'pytanie1Ctrl'
  })

  .state('pytanie2', {
    url: '/page14',
    templateUrl: 'templates/pytanie2.html',
    controller: 'pytanie2Ctrl'
  })

  .state('pytanie3', {
    url: '/page15',
    templateUrl: 'templates/pytanie3.html',
    controller: 'pytanie3Ctrl'
  })

  .state('wygrana', {
    url: '/page16',
    templateUrl: 'templates/wygrana.html',
    controller: 'wygranaCtrl'
  })

  .state('przegrana', {
    url: '/page12',
    templateUrl: 'templates/przegrana.html',
    controller: 'przegranaCtrl'
  })

$urlRouterProvider.otherwise('/page1/page2')

  

});